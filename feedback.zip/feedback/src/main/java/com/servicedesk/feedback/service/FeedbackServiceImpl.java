package com.servicedesk.feedback.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.servicedesk.feedback.bean.Feedback;
import com.servicedesk.feedback.repository.FeedbackRepository;


@Service
public class FeedbackServiceImpl implements FeedbackService{
		@Autowired
		private FeedbackRepository repository;

		@Override
		public void save(Feedback feed) {
			repository.save(feed);
			
		}

		@Override
		public void deleteById(String id) {
			repository.deleteById(id);
			
		}

		@Override
		public List<Feedback> findAll() {
			return repository.findAll();
		}

		@Override
		public Feedback findById(String id) {
			return repository.getById(id);
		}

		
		

	}


