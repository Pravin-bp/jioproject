package com.servicedesk.feedback.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Feedback {
	@Id
	private String ide;
	private int review;
	private String comment;
	private String user;
	public Feedback(String ide, int review, String comment, String user) {
		super();
		this.ide = ide;
		this.review = review;
		this.comment = comment;
		this.user = user;
	}
	public Feedback() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getIde() {
		return ide;
	}
	public void setIde(String ide) {
		this.ide = ide;
	}
	public int getReview() {
		return review;
	}
	public void setReview(int review) {
		this.review = review;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	@Override
	public String toString() {
		return "Feedback [ide=" + ide + ", review=" + review + ", comment=" + comment + ", user=" + user + "]";
	}
	
	


	

}
