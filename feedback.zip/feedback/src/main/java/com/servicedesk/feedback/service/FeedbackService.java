package com.servicedesk.feedback.service;

import java.util.List;

import com.servicedesk.feedback.bean.Feedback;


public interface FeedbackService {
	public void save(Feedback feed);
	public void deleteById(String id);
	public List<Feedback> findAll();
	public Feedback findById(String id);


}
